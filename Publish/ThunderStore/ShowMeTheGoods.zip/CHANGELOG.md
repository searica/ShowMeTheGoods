<div class="header">
	<h2>Versions 0.X.X</h2>
</div>
<table>
	<tbody>
		<tr>
			<th align="center">Version</th>
			<th align="center">Notes</th>
		</tr>
		<tr>
			<td align="center">0.2.2</td>
			<td align="left">
				<ul>
					<li>Added error handling for when other mods enable locations that have missing or invalid prefab names.</li>
				</ul>
			</td>
		</tr>
		<tr>
			<td align="center">0.2.1</td>
			<td align="left">
				<ul>
					<li>Prevent reading the map before locations are finished generating, should hopefully fix issue with sometimes thinking that all traders have been found when they haven't.</li>
				</ul>
			</td>
		</tr>
		<tr>
			<td align="center">0.2.0</td>
			<td align="left">
				<ul>
					<li>Fixed issue where clients could not detect all possible trader locations when searching for them.</li>
					<li>Made mod required on server (needed to fix the above issue).</li>
					<li>Fixed possibly being unable to read trade route map if you logged out and back in while the hint was showing.</li>
				</ul>
			</td>
		</tr>
		<tr>
			<td align="center">0.1.0</td>
			<td align="left">
				<ul>
					<li>Initial release.</li>
				</ul>
			</td>
		</tr>
	</tbody>
</table>